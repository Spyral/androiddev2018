USTH ICT 2018 Android Application Development
=====================================================

Students are expected to:

* Fork this repository to your github account
* Update student name and ID to this README file
* Push your commits regularly, with proper commit messages

Student Info
=======================

* Name: Hoang Duc Minh, Dang Vu Son Tung, Vu Hoang Linh 
* ID: USTHBI6-096, USTHBI6-145, USTHBI6-086
* Group ID: 9
* Project Name: IRC Client
